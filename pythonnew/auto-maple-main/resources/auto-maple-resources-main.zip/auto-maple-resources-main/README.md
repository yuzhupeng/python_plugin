<h1 align="center">Auto Maple Resources</h1> 
Community repository for Auto Maple command books and routines
            
